const mongoose = require('mongoose')
const bcrypt = require('bcrypt')

const userSchema = new mongoose.Schema({

  // here define the properties for the database fields

  email : {
    type:String,
    required:[true, "email address is required"],
    unique:true
  },
  username: {
    type:String,
    required:[true,"username is Required..."]
  },
  password: {
    type:String,
    required:[true,"Password is required.."]
  },
  createdAt: {
    type:Date,
    default:new Date(),
  }
}, {timestamps:true});

userSchema.pre("save", async function(){
    this.password = await bcrypt.hash(this.password,12);
});


module.exports = mongoose.model("User", userSchema)