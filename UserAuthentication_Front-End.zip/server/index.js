const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose")
const app = express();
// const PORT = 4000;
require("dotenv").config();
const cookieParser = require("cookie-parser");

const authroute = require("./Routes/AuthRoute.js")



// const MONGODB_URL="mongodb+srv://userauthenticatation:pPsjjvpZJZ7YiqSl@cluster0.zjshknq.mongodb.net/?retryWrites=true&w=majority";

console.log(` port form envirment variable`,process.env.PORT);
console.log(` mongodb url form envirment variable`,process.env.MONGODB_URL);
const mongourl = process.env.MONGODB_URL;

console.log(` parth idea ${mongourl}`);
mongoose.connect(mongourl)
.then(() => console.log("MongoDB is Connected..."))
.catch((err) => console.error(err))

app.listen(process.env.PORT, () => {
  console.log(`Server is listening on port ${process.env.PORT}`);
});

// app.use(cors());
// This is One way we can solve the cors error problem
app.use(cors(
  {
    origin: ["http://localhost:5173"],
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true,
  }
))

app.use(cookieParser());

app.use(express.json());

app.use("/api", authroute);