import React,{useState} from 'react'
import {Link} from "react-router-dom"
import { ToastContainer, toast } from 'react-toastify';
import axios from "axios";

const Signup = () => {


  const [inputvalues, setInputvalues] = useState({
    email : "",
    username: "",
    password : ""
  })
  const {email, username, password} = inputvalues;


  const handleOnchange = (e) => {
    const {name, value} = e.target;
    setInputvalues({
      ...inputvalues,
      [name]:value,
    });
  }

  const handleerror = (msg) => {
    toast.error(msg, {
      position:"bottom-left"
    })
  }

  const handlesucces = (msg) => {
    toast.success(msg,{
      position:"bottom-right"
    })

  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("form submited with data",inputvalues);
    try {
       const {data} = await axios.post("http://localhost:8000/api/signup",
       {
        ...inputvalues
       },
       {withCredentials:true}
       );


       const {success, message} = data;
       if(success){
        handlesucces(message)
       }
       else{
        handleerror(message)
       }

      
    } catch (error) {
      console.error(error)
    }

    setInputvalues({
      ...inputvalues,
      email: "",
      password: "",
      username: "",
    });













  }
  return (
    <div>

      <form onSubmit={handleSubmit}>
          <label htmlFor="email">Email: </label>
         <input type="text" name="email" id="email" value={email} placeholder='Enter Email' onChange={handleOnchange}/> <br /><br />
         <label htmlFor="username">UserName: </label>
         <input type="text" name="username" id="username" value={username} placeholder='Enter username' onChange={handleOnchange}/> <br /><br />
         <label htmlFor="password">Password: </label>
         <input type="password" name="password" id="password" value={password} placeholder='Enter password' onChange={handleOnchange}/> <br /><br />
         <button type='submit'>Submit</button>
         <span>If already have an account? <Link to="/login">Login</Link></span>

      </form>
      <ToastContainer/>

    </div>
  )
}

export default Signup