    const mongoose = require('mongoose');

    // mongodb url with credentials incluided
    // nothing but connection string

    // const db = "mongodb+srv://safarbpccs09042001:JRitSxyRJuuZEFiM@cluster0.zjshknq.mongodb.net/?retryWrites=true&w=majority";

    const db = "mongodb+srv://safarmansuri:L1OKcF6IBfI48zll@cluster0.zjshknq.mongodb.net/?retryWrites=true&w=majority";
    // const db = mongodb+srv://safarbpccs09042001:JRitSxyRJuuZEFiM@cluster0.zjshknq.mongodb.net/?retryWrites=true&w=majority


    mongoose.set("strictQuery", true, "useNewUrlParser", true);

    const connectDB = async () => {
            try {
                await mongoose.connect(db);
                console.log("MongoDB is Connected!! With out an excuse setup Your Project here only so you can work on it on weekend")
            } catch (error) {
                console.error(error);
                process.exit(1)
            }
    }

    module.exports = connectDB