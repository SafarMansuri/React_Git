const express = require('express');
const router = express.Router();


const Book = require("../../models/book.js");


// @route GET api/books/test
// @desc Test Book route
// @access public

// router.get("/test", (req, res) => { return res.send('Book Route Testing')})
// router.get("/test", (req, res) => (res.send('Book Route Testing')))
router.get("/test", (req, res) => res.send('Book Route Testing'))
// above all are the ways to write routes 


// @route GET api/books
// @desc Get All Books
// @access public
router.get("/" , (req, res) => (
    Book.find()
    .then((books) => res.json(books))
    .catch((err) => (res.status(404).json({nobooksfound : "No Books Found"})))
));


// @route GET api/books/:id
// @desc Get Single Book by id
// @access public
router.get("/:id", (req, res) => (
   Book.findById(req.params.id)
   .then((book) => (res.json(book)))
   .catch((err) => res.status(404).json({nobooksfound : "No Books Found"}))
));



// @route   POST api/books
// @desc    Add/save book
// @access  Public
router.post("/", (req,res) => (
    Book.create(req.body)
    .then((book) => (res.json({msg : "Book addedd successfully"})))
    .catch(err => res.status(400).json({error: "Unable to add this book"}))
));



// @route   PUT api/books/:id
// @desc    Update book by id
// @access  Public
router.put("/:id", (req, res) => (
    Book.findByIdAndUpdate(req.params.id, req.body)
    .then((book) => (res.json({msg: "Book Updated Successfully"})))
    .catch((err) => res.status(400).json({error: "Unable to Update this Book"}))
));


// @route   DELETE api/books/:id
// @desc    Delete book by id
// @access  Public

router.delete("/:id", (req, res) => (
    Book.findByIdAndDelete(req.params.id)
    .then((book) => (res.json({msg : "book Deleted successfully"})))
    .catch((err) => (res.status(400).json({error: "No Such book Found With this ID"})))
))


module.exports = router;

















