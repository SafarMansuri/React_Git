import React from 'react'

function CreateBook() {
  return (
    <div>CreateBook</div>
  )
}

export default CreateBook