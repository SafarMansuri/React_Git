import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import {createBrowserRouter, RouterProvider} from "react-router-dom"

// Bootstrap CSS
import "bootstrap/dist/css/bootstrap.min.css";
// Bootstrap Bundle JS
import "bootstrap/dist/js/bootstrap.bundle.min";

// importing the components for routing 
// import CreateBook from "./components/index.js"
// import ShowBookDetailes from "./components/index.js"
// import ShowBookList from "./components/index.js"
// import UpdateBookInfo from "./components/index.js"

import ShowBookList from './components/ShowBookList.jsx'
import CreateBook from './components/CreateBook.jsx'
import ShowBookDetails from './components/ShowBookDetails.jsx'
import UpdateBookInfo from './components/UpdateBookInfo.jsx'


const router = createBrowserRouter([
 {path: "/", element: <ShowBookList/>},
 {path: "/create-book", element: <CreateBook/>},
 {path: "/show-book/:id", element: <ShowBookDetails/>},
 {path: "/edit-book/:id", element: <UpdateBookInfo/>}
])


ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* <App /> */}

    <RouterProvider router={router}/>
  </React.StrictMode>,
)
