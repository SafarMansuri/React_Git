import BookCard from "./BookCard";
import CreateBook from "./CreateBook";
import ShowBookDetails from "./ShowBookDetails";
import ShowBookList from "./ShowBookList";
import UpdateBookInfo from "./UpdateBookInfo";


export default {

    BookCard,
    CreateBook,
    ShowBookDetails,
    ShowBookList,
    UpdateBookInfo
}