import React from 'react'
import axios from "axios"
import { useEffect, useState } from 'react'
import SimpleImageSlider from "react-simple-image-slider";

const Users = () => {

    const [Users, Setusers] = useState([]);
    const [images,Setimages] = useState([]);

    useEffect(() => {
        
       axios.get('https://dummyjson.com/users')
       .then((res) => {
        Setusers(res)
        console.log("responsese",res)
        return res;
    })
    .then((data) => {
        console.log("data",data);
        return data.data.users[0].image;
    })
    .then((Images) => {
        console.log("images",Images)

        
    })
        .catch((error) => (
            console.error("something went Wrong:",error)
        ))
    },[]);

    async function getUsers(){

        const response = await axios.get('https://dummyjson.com/users')
        console.log("rsponse:",response.data)
        // now access the image urls from the object
        const imagesurls = response.data.users.map((users) => (users.image));
        console.log("images url's:",imagesurls)
        // storing this image url's inside the array of objects

        const imageurlobject = response.data.users.map((users) => {
               return {url:users.image}
        });
        console.log("image url Object:-",imageurlobject)
        Setimages(imageurlobject)

    }

    useEffect(() => {
        getUsers()
    
     
    }, [])
    

   

  return (
   
    <div>
        {
            !images ? <h1>Loading</h1> :
            
            <div>
                <SimpleImageSlider
                width={896}
                height={704}
                images={images}
                showBullets={true}
                showNavs={true}
                autoPlay={true}
      />
            </div>
        }
       
    </div>
  )
}

export default Users