import React from 'react'
import { useEffect, useState } from 'react'
import axios from "axios"
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
const ReactSlick = () => {
    const [images, Setimages] = useState([]);
    const [open, setOpen] = useState(false);
    const [modalImage, SetModalImage] = useState(null)
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    async function getUsers(){

        const response = await axios.get('https://dummyjson.com/users')
        console.log("rsponse:",response.data)
        // now access the image urls from the object
        const imagesurls = response.data.users.map((users) => (users.image));
        // console.log("images url's:",imagesurls)
        // storing this image url's inside the array of objects

        const imageurlobject = response.data.users.map((users) => {
               return {url:users.image}
        });
        // console.log("image url Object:-",imageurlobject)
        Setimages(imageurlobject)

    }


    useEffect(() => {
        getUsers()
    
     
    }, [])

    const handleImageclick = (e,index) => {
        console.log("event.target",e.target)
        console.log("index",index)
        SetModalImage(e.target.src);
        handleOpen();    
    }
  return (
    <div>
         <ImageList sx={{ width: 500, height: 450 }} cols={3} rowHeight={164}>
      {images.map((item,index) => (
        <ImageListItem key={item.url}>
          <img
            srcSet={`${item.url}`}
            src={`${item.url}`}
            alt="images"
            loading="lazy"
            onClick={e => (handleImageclick(e,index))}
          />
        </ImageListItem>
      ))}
    </ImageList>


    <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Billi ka photu
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
            here we can see our selected Images
            <img src={modalImage} alt="billi ka photu" />
            <Slider {...settings}>
                <div>
                    <h3>1</h3>
                </div>
                <div>
                    <h3>2</h3>
                </div>
                <div>
                    <h3>3</h3>
                </div>
                <div>
                    <h3>4</h3>
                </div>
                <div>
                    <h3>5</h3>
                </div>
                <div>
                    <h3>6</h3>
                </div>
    </Slider>
          </Typography>
        </Box>
      </Modal>
    </div>
  )
}

export default ReactSlick