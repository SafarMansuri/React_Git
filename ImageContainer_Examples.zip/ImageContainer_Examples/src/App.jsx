import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
// import './App.css'
import Users from "./Components/Users"
import ReactSlick from "./Components/ReactSlick"
function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <h1>App COmponnet</h1>
        {/* <Users/> */}
        <ReactSlick/>
      </div>
    </>
  )
}

export default App
