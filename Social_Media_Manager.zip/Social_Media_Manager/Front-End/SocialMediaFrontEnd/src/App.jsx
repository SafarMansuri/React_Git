import './App.css'
import Grid from "./Tabs/Grid"
function App() {

  return (
    <>
      <div>
        <h1>App Component</h1>
        <div className="uploadfileform">
          
          {/* <UploadForm/> */}
          <Grid/>
        </div>
      </div>
    </>
  )
}

export default App
